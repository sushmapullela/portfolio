package com.samplegame;

public enum Images {
	BUGATTI, SKYPE, YAHOO, PEPSI, PRINGLES, FACEBOOK, STARBUCKS, JAVA, WINDOWS, CHARMINAR
}
